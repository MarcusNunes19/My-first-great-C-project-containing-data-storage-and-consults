#ifndef FUNCAD_H
#define FUNCAD_H

void checar_carac(char *vet, int tam);
void cadastrar_cliente();
void passagem();

#endif // FUNCAD_H