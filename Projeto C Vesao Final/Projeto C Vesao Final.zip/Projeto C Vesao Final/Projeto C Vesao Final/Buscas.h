#ifndef BUSCAS_H
#define BUSCAS_H

void reimprimirPassagem();
void chamarListaCliente();
void consultarCliente();

#endif // BUSCAS_H